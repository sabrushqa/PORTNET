package com.a.portnet_back.Repositories;

import com.a.portnet_back.Models.Demande;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;


public interface DemandeRepository extends JpaRepository<Demande, Long> {
    List<Demande> findByOperateurId(Long operateurId);
}

