package com.a.portnet_back.DTO;

public class OperateurRequestDTO {
    public String nomComplet;
    public String email;
    public String password;
    public String societe;
    public String telephone;
    public String adresse;
    public String ville;
    public String pays;
    public String rc;
    public String ice;
    public String ifiscale;
    public String patente;
    public String emailProfessionnel;
    public String domaineActivite;
    public String typeOperation;
    public boolean certifieISO;
    public String statutDouanier;
}
