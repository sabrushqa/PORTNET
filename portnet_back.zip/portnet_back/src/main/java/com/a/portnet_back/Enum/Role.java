package com.a.portnet_back.Enum;

public enum Role {
    SUPERVISEUR,
    OPERATEUR,
    AGENT
}