package com.a.portnet_back.Services;

import com.a.portnet_back.Models.Demande;
import com.a.portnet_back.Models.Document;
import com.a.portnet_back.Repositories.DemandeRepository;
import com.a.portnet_back.Repositories.DocumentRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

@Service
public class DocumentService {

    @Value("${app.upload.dir}")
    private String uploadDir;

    private final DocumentRepository documentRepository;
    private final DemandeRepository demandeRepository;

    public DocumentService(DocumentRepository documentRepository, DemandeRepository demandeRepository) {
        this.documentRepository = documentRepository;
        this.demandeRepository = demandeRepository;
    }

    public Document uploadDocument(Long demandeId, MultipartFile file) throws IOException {
        Demande demande = demandeRepository.findById(demandeId)
                .orElseThrow(() -> new RuntimeException("Demande introuvable"));

        // Construire chemin dossier : operateurId/categorie/numeroEnregistrement
        String dossierPath = uploadDir + File.separator + demande.getOperateur().getId()
                + File.separator + demande.getCategorie()
                + File.separator + demande.getNumeroEnregistrement();

        File directory = new File(dossierPath);
        if (!directory.exists()) {
            directory.mkdirs();
        }

        String fileName = UUID.randomUUID() + "_" + file.getOriginalFilename();
        File destination = new File(directory, fileName);
        file.transferTo(destination);

        Document doc = new Document();
        doc.setNom(file.getOriginalFilename());
        doc.setChemin(destination.getAbsolutePath());
        doc.setType(file.getContentType());
        doc.setDemande(demande);

        return documentRepository.save(doc);
    }

    public List<Document> getDocumentsByDemande(Long demandeId) {
        return documentRepository.findByDemandeId(demandeId);
    }
}
