package com.a.portnet_back.Models;

import com.a.portnet_back.Enum.Categorie;
import com.a.portnet_back.Enum.StatusDemande;
import jakarta.persistence.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "demandes")
public class Demande {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "numero_enregistrement", unique = true, nullable = false)
    private String numeroEnregistrement;

    @Enumerated(EnumType.STRING)
    private StatusDemande statut;
    @Column(name = "date_creation", nullable = false)
    private LocalDateTime dateCreation = LocalDateTime.now();


    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Categorie categorie;

    @ManyToOne
    @JoinColumn(name = "bureau_douanier_id")
    private BureauDouanier bureauDouanier;

    @OneToMany(mappedBy = "demande", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Document> documents = new ArrayList<>();

    @ManyToOne
    @JoinColumn(name = "devise_id")
    private Devise devise;

    @ManyToOne
    @JoinColumn(name = "marchandise_id")
    private Marchandise marchandise;

    @ManyToOne
    @JoinColumn(name = "operateur_id")
    private Operateur operateur;

    public Demande() {
    }



    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNumeroEnregistrement() {
        return numeroEnregistrement;
    }

    public void setNumeroEnregistrement(String numeroEnregistrement) {
        this.numeroEnregistrement = numeroEnregistrement;
    }

    public StatusDemande getStatut() {
        return statut;
    }

    public void setStatut(StatusDemande statut) {
        this.statut = statut;
    }


    public Categorie getCategorie() {
        return categorie;
    }

    public void setCategorie(Categorie categorie) {
        this.categorie = categorie;
    }

    public BureauDouanier getBureauDouanier() {
        return bureauDouanier;
    }

    public void setBureauDouanier(BureauDouanier bureauDouanier) {
        this.bureauDouanier = bureauDouanier;
    }

    public List<Document> getDocuments() {
        return documents;
    }

    public void setDocuments(List<Document> documents) {
        this.documents = documents;
    }

    public Devise getDevise() {
        return devise;
    }

    public void setDevise(Devise devise) {
        this.devise = devise;
    }

    public Marchandise getMarchandise() {
        return marchandise;
    }

    public void setMarchandise(Marchandise marchandise) {
        this.marchandise = marchandise;
    }

    public Operateur getOperateur() {
        return operateur;
    }

    public void setOperateur(Operateur operateur) {
        this.operateur = operateur;
    }
    public LocalDateTime getDateCreation() {
        return dateCreation;
    }

    public void setDateCreation(LocalDateTime dateCreation) {
        this.dateCreation = dateCreation;
    }

}
