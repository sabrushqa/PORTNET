package com.a.portnet_back.Repositories;

import com.a.portnet_back.Models.Pays;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaysRepository extends JpaRepository<Pays, Long> {}
