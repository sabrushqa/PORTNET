package com.a.portnet_back.Repositories;

import com.a.portnet_back.Models.Devise;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DeviseRepository extends JpaRepository<Devise, Long> {

}
