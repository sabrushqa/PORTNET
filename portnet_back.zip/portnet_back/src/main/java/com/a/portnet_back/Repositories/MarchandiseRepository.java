package com.a.portnet_back.Repositories;

import com.a.portnet_back.Models.Marchandise;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MarchandiseRepository extends JpaRepository<Marchandise, Long> {}

