package com.a.portnet_back.Controllers;

import com.a.portnet_back.DTO.DemandeCreationRequest;
import com.a.portnet_back.Services.DemandeCreationService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/demandes")
public class DemandeCreationController {

    private final DemandeCreationService demandeCreationService;
    private final ObjectMapper objectMapper;

    public DemandeCreationController(DemandeCreationService demandeCreationService, ObjectMapper objectMapper) {
        this.demandeCreationService = demandeCreationService;
        this.objectMapper = objectMapper;
    }

    @PostMapping(consumes = {"multipart/form-data"})
    public ResponseEntity<?> createDemande(
            @RequestParam("demande") String demandeJson,
            @RequestParam(value = "documents", required = false) MultipartFile[] documents) {

        try {

            DemandeCreationRequest request = objectMapper.readValue(demandeJson, DemandeCreationRequest.class);


            request.setDocuments(documents != null ? List.of(documents) : null);
            
            demandeCreationService.createDemandeWithMarchandiseAndDocuments(request);

            return ResponseEntity.ok("Demande créée avec succès");
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().body("Erreur lors de la création de la demande: " + e.getMessage());
        }
    }
}
