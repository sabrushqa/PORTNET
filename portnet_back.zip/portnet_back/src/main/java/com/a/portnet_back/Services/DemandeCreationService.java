package com.a.portnet_back.Services;

import com.a.portnet_back.DTO.DemandeCreationRequest;
import com.a.portnet_back.Enum.StatusDemande;
import com.a.portnet_back.Models.*;
import com.a.portnet_back.Repositories.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
public class DemandeCreationService {

    private final DemandeRepository demandeRepository;
    private final MarchandiseRepository marchandiseRepository;
    private final BureauDouanierRepository bureauRepository;
    private final DeviseRepository deviseRepository;
    private final PaysRepository paysRepository;
    private final DocumentRepository documentRepository;
    private final OperateurService operateurService; // Pour récupérer operateur connecté

    // Injection via constructeur
    public DemandeCreationService(DemandeRepository demandeRepository,
                                  MarchandiseRepository marchandiseRepository,
                                  BureauDouanierRepository bureauRepository,
                                  DeviseRepository deviseRepository,
                                  PaysRepository paysRepository,
                                  DocumentRepository documentRepository,
                                  OperateurService operateurService) {
        this.demandeRepository = demandeRepository;
        this.marchandiseRepository = marchandiseRepository;
        this.bureauRepository = bureauRepository;
        this.deviseRepository = deviseRepository;
        this.paysRepository = paysRepository;
        this.documentRepository = documentRepository;
        this.operateurService = operateurService;
    }

    @Transactional
    public Demande createDemandeWithMarchandiseAndDocuments(DemandeCreationRequest request) throws IOException {
        // 1. Créer Marchandise
        Marchandise marchandise = new Marchandise();
        marchandise.setDesignation(request.getMarchandise().getDesignation());
        marchandise.setQuantite(request.getMarchandise().getQuantite());
        marchandise.setMontant(request.getMarchandise().getMontant());
        marchandise.setCodeSh(request.getMarchandise().getCodeSh());
        if (request.getMarchandise().getPaysId() != null) {
            paysRepository.findById(request.getMarchandise().getPaysId())
                    .ifPresent(marchandise::setPays);
        }
        marchandise = marchandiseRepository.save(marchandise);

        // 2. Créer Demande
        Demande demande = new Demande();
        demande.setCategorie(request.getCategorie());
        demande.setMarchandise(marchandise);

        // Auto dateCreation dans entity Demande
        demande.setStatut(StatusDemande.EN_ATTENTE);

        // Lier bureauDouanier si fourni
        if (request.getBureauDouanierId() != null) {
            bureauRepository.findById(request.getBureauDouanierId())
                    .ifPresent(demande::setBureauDouanier);
        }

        // Lier devise si fourni
        if (request.getDeviseId() != null) {
            deviseRepository.findById(request.getDeviseId())
                    .ifPresent(demande::setDevise);
        }

        // Lier opérateur connecté
        demande.setOperateur(operateurService.getOperateurConnecte());

        // Générer numéro unique
        String numero = "DEM-" + System.currentTimeMillis();
        demande.setNumeroEnregistrement(numero);

        // Sauvegarder demande (sans documents encore)
        demande = demandeRepository.save(demande);

        // 3. Sauvegarder documents (fichiers)
        List<Document> savedDocs = new ArrayList<>();
        if (request.getDocuments() != null) {
            String baseDir = "chemin/de/ton/dossier/upload"; // adapte ici
            File baseDirFile = new File(baseDir);
            if (!baseDirFile.exists()) baseDirFile.mkdirs();

            for (MultipartFile file : request.getDocuments()) {
                String fileName = UUID.randomUUID() + "_" + file.getOriginalFilename();
                File destFile = new File(baseDirFile, fileName);
                file.transferTo(destFile);

                Document doc = new Document();
                doc.setNom(file.getOriginalFilename());
                doc.setChemin(destFile.getAbsolutePath());
                doc.setType(file.getContentType());
                doc.setDemande(demande);
                savedDocs.add(documentRepository.save(doc));
            }
        }

        demande.setDocuments(savedDocs);

        return demande;
    }
}
