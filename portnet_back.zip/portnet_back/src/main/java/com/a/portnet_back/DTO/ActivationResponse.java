package com.a.portnet_back.DTO;

public class ActivationResponse {
    private String message;

    public ActivationResponse(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}
