package com.a.portnet_back.Repositories;

import com.a.portnet_back.Models.BureauDouanier;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BureauDouanierRepository extends JpaRepository<BureauDouanier, Long> {}
