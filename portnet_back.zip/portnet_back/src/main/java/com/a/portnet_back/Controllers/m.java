package com.a.portnet_back.Controllers;

import com.a.portnet_back.Models.Marchandise;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

//@RestController
//(@RequestMapping("/api/marchandises")
//public class MarchandiseController {

    //@PostMapping
    //public ResponseEntity<Marchandise> //createMarchandise(@RequestBody Marchandise marchandise) {
        // sauvegarde marchandise...
        //return ResponseEntity.ok(savedMarchandise);
    //}
//}

