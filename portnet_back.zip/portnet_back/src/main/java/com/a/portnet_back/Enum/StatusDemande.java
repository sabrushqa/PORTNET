package com.a.portnet_back.Enum;

public enum StatusDemande {
    EN_ATTENTE,
    ACCEPTEE,
    REFUSEE
}
