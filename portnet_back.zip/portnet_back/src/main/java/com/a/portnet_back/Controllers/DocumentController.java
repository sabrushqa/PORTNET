package com.a.portnet_back.Controllers;

import com.a.portnet_back.Models.Document;
import com.a.portnet_back.Services.DocumentService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/documents")
public class DocumentController {

    private final DocumentService documentService;

    public DocumentController(DocumentService documentService) {
        this.documentService = documentService;
    }

    @PostMapping("/upload/{demandeId}")
    public ResponseEntity<Document> uploadDocument(
            @PathVariable Long demandeId,
            @RequestParam("file") MultipartFile file) {

        try {
            Document doc = documentService.uploadDocument(demandeId, file);
            return ResponseEntity.ok(doc);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping("/demande/{demandeId}")
    public ResponseEntity<List<Document>> getDocumentsByDemande(@PathVariable Long demandeId) {
        return ResponseEntity.ok(documentService.getDocumentsByDemande(demandeId));
    }
}
