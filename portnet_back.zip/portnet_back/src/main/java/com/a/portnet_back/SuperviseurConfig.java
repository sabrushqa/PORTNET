package com.a.portnet_back;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SuperviseurConfig {
//
    // @Value("${superviseur.email}")
   // private String email;

   // @Value("${superviseur.password}")
    //private String password;


    //public String getEmail() {
       // return email;
    }

    //public String getPassword() {
        //return password;
    //}

//}
