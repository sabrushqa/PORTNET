package com.a.portnet_back.Repositories;


import com.a.portnet_back.Models.Document;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DocumentRepository extends JpaRepository<Document, Long> {
    List<Document> findByDemandeId(Long demandeId);
}

